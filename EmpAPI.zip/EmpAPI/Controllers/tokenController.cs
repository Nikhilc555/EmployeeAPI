﻿using Dapper;
using EmpAPI.Context;
using EmpAPI.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.IdentityModel.Tokens;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;
using static Microsoft.EntityFrameworkCore.DbLoggerCategory;

namespace EmpAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class tokenController : Controller
    {
        public IConfiguration _configuration;
        private readonly EmployeeContext _context;
        public tokenController(IConfiguration config, EmployeeContext context)
        {
            _configuration = config;
            _context = context;
        }
        [HttpPost]
        public async Task<IActionResult> Post(Login _userData)
        {
            if (_userData != null && _userData.user_name != null && _userData.password != null)
            {
                var user = await GetUser(_userData.user_name, _userData.password);

                if (user != null)
                {
                    //create claims details based on the user information
                    var claims = new[] {
                        new Claim(JwtRegisteredClaimNames.Sub, _configuration["Jwt:Subject"]),
                        new Claim(JwtRegisteredClaimNames.Jti, Guid.NewGuid().ToString()),
                        new Claim(JwtRegisteredClaimNames.Iat, DateTime.UtcNow.ToString()),
                        new Claim("UserId", user.user_reference.ToString()),
                        new Claim("DisplayName", user.name),
                        new Claim("UserName", user.user_name)
                    };

                    var key = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(_configuration["Jwt:Key"]));
                    var signIn = new SigningCredentials(key, SecurityAlgorithms.HmacSha256);
                    var token = new JwtSecurityToken(
                        _configuration["Jwt:Issuer"],
                        _configuration["Jwt:Audience"],
                        claims,
                        expires: DateTime.UtcNow.AddMinutes(10),
                        signingCredentials: signIn);

                    return Ok(new JwtSecurityTokenHandler().WriteToken(token));
                }
                else
                {
                    return BadRequest("Invalid credentials");
                }
            }
            else
            {
                return BadRequest();
            }
        }
        private async Task<TblUsers> GetUser(string username, string password)
        {
            //return await _context.TblUsers.FirstOrDefaultAsync(u => u.user_name == email && u.password == password);
            var query = $"SELECT * FROM tbl_users WHERE user_name = '{username}' and password = '{password}'";
            using (var connection = _context.CreateConnection())
            {
                var employee = await connection.QuerySingleOrDefaultAsync<TblUsers>(query);
                return employee;
            }
        }
    }
}
