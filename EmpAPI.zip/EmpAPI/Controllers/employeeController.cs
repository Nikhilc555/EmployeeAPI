﻿using EmpAPI.DTOs;
using EmpAPI.Models;
using EmpAPI.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace EmpAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    [Authorize]
    public class employeeController : Controller
    {
        //public IActionResult Index()
        //{
        //    return View();
        //}
        private readonly Iempservices _empService;

        public employeeController(Iempservices empService)
        {
            _empService = empService;
        }

        [HttpGet]
        [Route("getEmployees")]
        public async Task<ServiceResponse<List<EmployeeDTO>>> GetEmployees()
        {
            //_logger.LogInformation("Get New customer has been accessed");
            return await _empService.GetAllEmployee();
        }

        [HttpPost]
        [Route("createEmployee")]
        public async Task<ServiceResponse<List<TblEmployee>>> Create([FromBody] EmpListDTO employee)
        {
            var emp = await _empService.CreateEmployee(employee);

            return emp;
        }
        [HttpDelete("deleteEmployee/{id}")]
        public async Task<ActionResult> Delete(int id)
        {
            await _empService.DeleteEmployee(id);
            return NoContent();
        }
        [HttpPut]
        [Route("updateEmployee")]
        public async Task<ServiceResponse<List<TblEmployee>>>  Update([FromBody] EmployeeListDTO employee)
        {

            var emp = await _empService.UpdateEmployee(employee);

            return emp;
        }
    }
}
