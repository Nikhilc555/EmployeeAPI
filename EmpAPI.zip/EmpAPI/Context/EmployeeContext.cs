﻿using Microsoft.Data.SqlClient;
using System.Data;

namespace EmpAPI.Context
{
    public class EmployeeContext
    {
        private readonly IConfiguration _configuration;
        private readonly string _connectionString;
        public EmployeeContext(IConfiguration configuration)
        {
            _configuration = configuration;
            _connectionString = _configuration.GetConnectionString("EmployeeDb");
        }
        public IDbConnection CreateConnection()
            => new SqlConnection(_connectionString);
    }
}
