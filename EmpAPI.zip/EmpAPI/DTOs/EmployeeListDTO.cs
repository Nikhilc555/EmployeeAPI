﻿namespace EmpAPI.DTOs
{
    public class EmployeeListDTO
    {
        public List<EmployeeDTO> Data { get; set; }
    }
}
