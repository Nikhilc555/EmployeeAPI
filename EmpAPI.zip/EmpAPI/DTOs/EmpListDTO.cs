﻿namespace EmpAPI.DTOs
{
    public class EmpListDTO
    {
        public List<EmpAddDTO> Data { get; set; }
    }
}
