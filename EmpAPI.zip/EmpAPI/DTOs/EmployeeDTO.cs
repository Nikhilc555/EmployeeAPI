﻿namespace EmpAPI.DTOs
{
    public class EmployeeDTO
    {
        public int EmpReference { get; set; }
        public string? EmpName { get; set; }
        public string? EmpUserid { get; set; }
        public string? EmpPass { get; set; }
        public string? EmpMob { get; set; }
        public string? EmpEmail { get; set; }
        public string? EmpAddress { get; set; }
        public string? EmpDepartment { get; set; }
        public string? EmpUserType { get; set; }
        public string? EmpReportingTo { get; set; }
    }
}
