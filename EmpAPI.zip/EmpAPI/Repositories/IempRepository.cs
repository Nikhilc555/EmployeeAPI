﻿using EmpAPI.Models;

namespace EmpAPI.Repositories
{
    public interface IempRepository
    {
        Task<IEnumerable<TblEmployee>> Get();
        Task<TblEmployee> Get(int? Id);
        Task<TblEmployee> GetWithName(string? EmpName);
        Task<TblEmployee> GetWithUserName(string? UserName);
        Task<TblEmployee> Create(TblEmployee employee);
        Task Update(TblEmployee employee);
        Task Delete(int id);
    }
}
