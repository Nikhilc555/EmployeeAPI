﻿using Dapper;
using EmpAPI.Context;
using EmpAPI.Models;
using Microsoft.EntityFrameworkCore;
using System.Data;
using System.Runtime.Intrinsics.Arm;
using static Microsoft.EntityFrameworkCore.DbLoggerCategory.Database;

namespace EmpAPI.Repositories
{
    public class empRepository : IempRepository
    {
        private readonly EmployeeContext _context;

        public empRepository(EmployeeContext context)
        {
            _context = context;
        }
        public async Task<TblEmployee> Create(TblEmployee employee)
        {
            var query = "INSERT INTO tbl_employee (emp_name, emp_userid, emp_pass, emp_mob, emp_email, emp_address, emp_dep, emp_usertype, emp_reporting) VALUES (@emp_name, @emp_userid, @emp_pass, @emp_mob, @emp_email, @emp_address, @emp_dep, @emp_usertype, @emp_reporting)";
            var parameters = new DynamicParameters();
            parameters.Add("emp_name", employee.emp_name, DbType.String);
            parameters.Add("emp_userid", employee.emp_userid, DbType.String);
            parameters.Add("emp_pass", employee.emp_pass, DbType.String);
            parameters.Add("emp_mob", employee.emp_mob, DbType.String);
            parameters.Add("emp_email", employee.emp_email, DbType.String);
            parameters.Add("emp_address", employee.emp_address, DbType.String);
            parameters.Add("emp_dep", employee.emp_dep, DbType.Int32);
            parameters.Add("emp_usertype", employee.emp_usertype, DbType.Int32);
            parameters.Add("emp_reporting", employee.emp_reporting, DbType.Int32);
            using (var connection = _context.CreateConnection())
            {
                await connection.ExecuteAsync(query, parameters);
            }
            return employee;
        }

        public async Task Delete(int id)
        {
            var query = "DELETE FROM tbl_employee WHERE emp_reference = @Id";
            using (var connection = _context.CreateConnection())
            {
                await connection.ExecuteAsync(query, new { id });
            }
        }

        public async Task<IEnumerable<TblEmployee>> Get()
        {
            var query = "SELECT * FROM tbl_employee";
            using (var connection = _context.CreateConnection())
            {
                var employee = connection.Query<TblEmployee>(query).ToList();
                return employee;
            }
        }

        public async Task<TblEmployee> Get(int? Id)
        {
            var query = "SELECT * FROM tbl_employee WHERE emp_reference = @Id";
            using (var connection = _context.CreateConnection())
            {
                var employee = await connection.QuerySingleOrDefaultAsync<TblEmployee>(query, new { Id });
                return employee;
            }
        }

        public async Task<TblEmployee> GetWithName(string? EmpName)
        {
            var query = "SELECT * FROM tbl_employee WHERE emp_name = @EmpName";
            using (var connection = _context.CreateConnection())
            {
                var employee = await connection.QuerySingleOrDefaultAsync<TblEmployee>(query, new { EmpName });
                return employee;
            }
        }

        public async Task<TblEmployee> GetWithUserName(string? UserName)
        {
            var query = "SELECT * FROM tbl_employee WHERE emp_userid = @UserName";
            using (var connection = _context.CreateConnection())
            {
                var employee = await connection.QuerySingleOrDefaultAsync<TblEmployee>(query, new { UserName });
                return employee;
            }
        }

        public async Task Update(TblEmployee employee)
        {
            var query = "UPDATE tbl_employee SET emp_name = @emp_name, emp_userid = @emp_userid, emp_pass = @emp_pass, emp_mob = @emp_mob, emp_email = @emp_email, emp_address = @emp_address, emp_dep = @emp_dep, emp_usertype = @emp_usertype, emp_reporting = @emp_reporting WHERE emp_reference = @Id";
            var parameters = new DynamicParameters();
            parameters.Add("Id", employee.emp_reference, DbType.Int32);
            parameters.Add("emp_name", employee.emp_name, DbType.String);
            parameters.Add("emp_userid", employee.emp_userid, DbType.String);
            parameters.Add("emp_pass", employee.emp_pass, DbType.String);
            parameters.Add("emp_mob", employee.emp_mob, DbType.String);
            parameters.Add("emp_email", employee.emp_email, DbType.String);
            parameters.Add("emp_address", employee.emp_address, DbType.String);
            parameters.Add("emp_dep", employee.emp_dep, DbType.Int32);
            parameters.Add("emp_usertype", employee.emp_usertype, DbType.Int32);
            parameters.Add("emp_reporting", employee.emp_reporting, DbType.Int32);
            using (var connection = _context.CreateConnection())
            {
                await connection.ExecuteAsync(query, parameters);
            }
        }
    }
}
