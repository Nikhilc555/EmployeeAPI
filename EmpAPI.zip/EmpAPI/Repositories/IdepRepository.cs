﻿using EmpAPI.Models;

namespace EmpAPI.Repositories
{
    public interface IdepRepository
    {
        Task<TblDepartment> Get(int? Id);
        Task<TblDepartment> GetWithName(string? dep);
    }
}
