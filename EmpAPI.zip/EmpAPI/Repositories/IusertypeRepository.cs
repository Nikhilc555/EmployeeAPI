﻿using EmpAPI.Models;

namespace EmpAPI.Repositories
{
    public interface IusertypeRepository
    {
        Task<TblUsertype> Get(int? Id);
        Task<TblUsertype> GetWithName(string? ut);
    }
}
