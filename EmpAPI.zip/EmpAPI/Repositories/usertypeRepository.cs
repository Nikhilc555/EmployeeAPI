﻿using Dapper;
using EmpAPI.Context;
using EmpAPI.Models;
using Microsoft.EntityFrameworkCore;
using static Microsoft.EntityFrameworkCore.DbLoggerCategory.Database;

namespace EmpAPI.Repositories
{
    public class usertypeRepository : IusertypeRepository
    {
        private readonly EmployeeContext _context;

        public usertypeRepository(EmployeeContext context)
        {
            _context = context;
        }
        public async Task<TblUsertype> Get(int? Id)
        {
            var query = "SELECT * FROM tbl_usertype WHERE ut_reference = @Id";
            using (var connection = _context.CreateConnection())
            {
                var usertype = await connection.QuerySingleOrDefaultAsync<TblUsertype>(query, new { Id });
                return usertype;
            }
        }

        public async Task<TblUsertype> GetWithName(string? ut)
        {
            var query = "SELECT * FROM tbl_usertype WHERE user_type = @ut";
            using (var connection = _context.CreateConnection())
            {
                var usertype = await connection.QuerySingleOrDefaultAsync<TblUsertype>(query, new { ut });
                return usertype;
            }
        }
    }
}
