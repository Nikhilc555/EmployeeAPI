﻿using Dapper;
using EmpAPI.Context;
using EmpAPI.Models;
using Microsoft.EntityFrameworkCore;
using System.Data;
using System.Runtime.Intrinsics.Arm;

namespace EmpAPI.Repositories
{
    public class depRepository : IdepRepository
    {
        private readonly EmployeeContext _context;

        public depRepository(EmployeeContext context)
        {
            _context = context;
        }
        public async Task<TblDepartment> Get(int? Id)
        {
            var query = "SELECT * FROM tbl_department WHERE dep_reference = @Id";
            using (var connection = _context.CreateConnection())
            {
                var department = await connection.QuerySingleOrDefaultAsync<TblDepartment>(query, new { Id });
                return department;
            }
        }

        public async Task<TblDepartment> GetWithName(string? dep)
        {
            var query = "SELECT * FROM tbl_department WHERE dep_name = @dep";
            //var parameters = new DynamicParameters();
            //parameters.Add("dep", dep, DbType.String);
            using (var connection = _context.CreateConnection())
            {
                var department = await connection.QuerySingleOrDefaultAsync<TblDepartment>(query, new { dep });
                return department;
            }
        }
    }
}
