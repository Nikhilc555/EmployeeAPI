﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

namespace EmpAPI.Models;

public partial class TblDepartment
{
    [Key]
    public int dep_reference { get; set; }
    public string? dep_name { get; set; }

    //[InverseProperty("EmpDepNavigation")]
    //public virtual ICollection<TblEmployee> TblEmployees { get; } = new List<TblEmployee>();
}
