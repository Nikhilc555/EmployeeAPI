﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

namespace EmpAPI.Models;

public partial class TblEmployee
{
    [Key]
    public int emp_reference { get; set; }
    public string? emp_name { get; set; }
    public string? emp_userid { get; set; }
    public string? emp_pass { get; set; }
    public string? emp_mob { get; set; }
    public string? emp_email { get; set; }
    public string? emp_address { get; set; }
    public int? emp_dep { get; set; }
    public int? emp_usertype { get; set; }
    public int? emp_reporting { get; set; }
}
