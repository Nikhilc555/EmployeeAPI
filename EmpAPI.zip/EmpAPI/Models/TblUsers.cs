﻿using System.ComponentModel.DataAnnotations;

namespace EmpAPI.Models
{
    public class TblUsers
    {
        [Key]
        public int user_reference { get; set; }
        public string? user_name { get; set; }
        public string? password { get; set; }
        public string? name { get; set; }
    }
}
