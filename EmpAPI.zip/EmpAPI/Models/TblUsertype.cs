﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

namespace EmpAPI.Models;

public partial class TblUsertype
{
    [Key]
    public int ut_reference { get; set; }
    public string? user_type { get; set; }

    //[InverseProperty("EmpUsertypeNavigation")]
    //public virtual ICollection<TblEmployee> TblEmployees { get; } = new List<TblEmployee>();
}
