﻿using EmpAPI.DTOs;
using EmpAPI.Models;
using EmpAPI.Repositories;

namespace EmpAPI.Services
{
    public class empServices : Iempservices
    {
        private readonly IempRepository _empRepo;
        private readonly IusertypeRepository _utRepo; 
        private readonly IdepRepository _depRepo;

        public empServices(IempRepository empRepo, IusertypeRepository utRepo, IdepRepository depRepo)
        {
            _empRepo = empRepo;
            _utRepo = utRepo;
            _depRepo = depRepo;
        }
        public async Task<ServiceResponse<List<TblEmployee>>> CreateEmployee(EmpListDTO empDTO)
        {
            ServiceResponse<List<TblEmployee>> _response = new ServiceResponse<List<TblEmployee>>();
            try
            {
                List<TblEmployee> emplist = new List<TblEmployee>();
                foreach (var emp in empDTO.Data) {

                    var empusername = await _empRepo.GetWithUserName(emp.EmpUserid);
                    if (empusername == null)
                    {

                        var dep = await _depRepo.GetWithName(emp.EmpDepartment);
                        var ut = await _utRepo.GetWithName(emp.EmpUserType);
                        var report = await _empRepo.GetWithName(emp.EmpReportingTo);
                        if (dep == null)
                        {
                            _response.Success = false;
                            _response.Data = null;
                            _response.Message = "Department does not exist";
                            return _response;
                        }
                        if (ut == null)
                        {
                            _response.Success = false;
                            _response.Data = null;
                            _response.Message = "Usertype does not exist";
                            return _response;
                        }

                        TblEmployee _employee = new TblEmployee()
                        {
                            emp_name = emp.EmpName,
                            emp_userid = emp.EmpUserid,
                            emp_pass = emp.EmpPass,
                            emp_mob = emp.EmpMob,
                            emp_email = emp.EmpEmail,
                            emp_address = emp.EmpAddress,
                            emp_dep = dep.dep_reference,
                            emp_usertype = ut.ut_reference,
                            emp_reporting = (report == null ? 0 : report.emp_reference)
                        };

                        if (await _empRepo.Create(_employee) == null)
                        {
                            _response.Error = "RepoError";
                            _response.Success = false;
                            _response.Data = null;
                            return _response;
                        }

                        emplist.Add(_employee);
                    }
                    else
                    {
                        _response.Error = "Username already exists";
                        _response.Success = false;
                        _response.Data = null;
                        return _response;
                    }
                }
                _response.Success = true;
                _response.Data = emplist;
                _response.Message = "Request processed successfully";
            }
            catch(Exception ex)
            {
                _response.Success = false;
                _response.Data = null;
                _response.Message = "Error";
                _response.ErrorMessages = new List<string> { Convert.ToString(ex.Message) };
            }
            return _response;
        }

        public async Task<ServiceResponse<string>> DeleteEmployee(int id)
        {
            ServiceResponse<string> _response = new ServiceResponse<string>();

            try
            {
                var empusername = await _empRepo.Get(id);
                if(empusername == null)
                {
                    _response.Success = true;
                    _response.Message = "Employee does not exist";
                }
                else
                {
                    await _empRepo.Delete(id);
                    _response.Success = true;
                    _response.Message = "Deleted";
                }
            }
            catch(Exception ex)
            {
                _response.Success = false;
                _response.Data = null;
                _response.Message = "Error";
                _response.ErrorMessages = new List<string> { Convert.ToString(ex.Message) };
            }
            return _response;
        }

        public async Task<ServiceResponse<List<EmployeeDTO>>> GetAllEmployee()
        {
            ServiceResponse<List<EmployeeDTO>> _response = new ServiceResponse<List<EmployeeDTO>>();
            try
            {
                var empResultDto = new List<EmployeeDTO>();
                var empList = await _empRepo.Get();

                foreach (var emp in empList)
                {
                    var employee = new EmployeeDTO();

                    var usertype = await _utRepo.Get(emp.emp_usertype);
                    var department = await _depRepo.Get(emp.emp_dep);
                    var reporting = await _empRepo.Get(emp.emp_reporting);

                    employee.EmpReference = emp.emp_reference;
                    employee.EmpName = emp.emp_name;
                    employee.EmpUserid = emp.emp_userid;
                    employee.EmpPass = emp.emp_pass;
                    employee.EmpMob = emp.emp_mob;
                    employee.EmpEmail = emp.emp_email;
                    employee.EmpAddress = emp.emp_address;
                    employee.EmpDepartment = department == null ? "" : department.dep_name;
                    employee.EmpUserType = usertype == null ? "" : usertype.user_type;
                    employee.EmpReportingTo = reporting == null ? "" : reporting.emp_name;

                    empResultDto.Add(employee);

                }
                _response.Success = true;
                _response.Message = "ok";
                _response.Data = empResultDto;
            }
            catch (Exception ex) 
            {
                _response.Success = false;
                _response.Data = null;
                _response.Message = "Error";
                _response.ErrorMessages = new List<string> { Convert.ToString(ex.Message) };
            }
            return _response;
        }

        public async Task<ServiceResponse<EmployeeDTO>> GetEmployee(int Id)
        {
            ServiceResponse<EmployeeDTO> _response = new ServiceResponse<EmployeeDTO>();
            try
            {
                var empl = await _empRepo.Get(Id);

                var employee = new EmployeeDTO();

                var usertype = await _utRepo.Get(empl.emp_usertype);
                var department = await _depRepo.Get(empl.emp_dep);
                var reporting = await _empRepo.Get(empl.emp_reporting);

                employee.EmpReference = empl.emp_reference;
                employee.EmpName = empl.emp_name;
                employee.EmpUserid = empl.emp_userid;
                employee.EmpPass = empl.emp_pass;
                employee.EmpMob = empl.emp_mob;
                employee.EmpEmail = empl.emp_email;
                employee.EmpAddress = empl.emp_address;
                employee.EmpDepartment = department.dep_name;
                employee.EmpUserType = usertype.user_type;
                employee.EmpReportingTo = reporting.emp_name;

                _response.Success = true;
                _response.Message = "ok";
                _response.Data = employee;
            }
            catch (Exception ex)
            {
                _response.Success = false;
                _response.Data = null;
                _response.Message = "Error";
                _response.ErrorMessages = new List<string> { Convert.ToString(ex.Message) };
            }
            return _response;
        }

        public async Task<ServiceResponse<List<TblEmployee>>> UpdateEmployee(EmployeeListDTO updateempDto)
        {
            ServiceResponse<List<TblEmployee>> _response = new ServiceResponse<List<TblEmployee>>();

            try
            {

                List<TblEmployee> emplist = new List<TblEmployee>();

                foreach (var emp in updateempDto.Data)
                {

                    var usertype = await _utRepo.GetWithName(emp.EmpUserType);
                    var department = await _depRepo.GetWithName(emp.EmpDepartment);
                    var reporting = await _empRepo.GetWithName(emp.EmpReportingTo);
                    if (usertype == null)
                    {
                        _response.Success = false;
                        _response.Message = "Usertype Not Found";
                        _response.Data = null;
                        return _response;

                    }
                    if (department == null)
                    {
                        _response.Success = false;
                        _response.Message = "Department Not Found";
                        _response.Data = null;
                        return _response;

                    }
                    var toUpdate = await _empRepo.Get(emp.EmpReference);
                    if (toUpdate == null)
                    {
                        _response.Success = false;
                        _response.Message = "Employee Not Found";
                        _response.Data = null;
                        return _response;

                    }
                    toUpdate.emp_name = emp.EmpName;
                    toUpdate.emp_userid = emp.EmpUserid;
                    toUpdate.emp_pass = emp.EmpPass;
                    toUpdate.emp_mob = emp.EmpMob;
                    toUpdate.emp_email = emp.EmpEmail;
                    toUpdate.emp_address = emp.EmpAddress;
                    toUpdate.emp_dep = department.dep_reference;
                    toUpdate.emp_usertype = usertype.ut_reference;
                    toUpdate.emp_reporting = reporting == null ? 0 : reporting.emp_reference;

                    await _empRepo.Update(toUpdate);

                    emplist.Add(toUpdate);
                }

                _response.Success = true;
                _response.Message = "Updated";
                _response.Data = emplist;

            }
            catch (Exception ex)
            {

                _response.Success = false;
                _response.Data = null;
                _response.Message = "Error";
                _response.ErrorMessages = new List<string> { Convert.ToString(ex.Message) };
            }
            return _response;
        }
    }
}
