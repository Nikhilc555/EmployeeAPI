﻿using EmpAPI.DTOs;
using EmpAPI.Models;

namespace EmpAPI.Services
{
    public interface Iempservices
    {
        Task<ServiceResponse<List<EmployeeDTO>>> GetAllEmployee();
        Task<ServiceResponse<EmployeeDTO>> GetEmployee(int Id);
        Task<ServiceResponse<List<TblEmployee>>> CreateEmployee(EmpListDTO empDTO);
        Task<ServiceResponse<List<TblEmployee>>> UpdateEmployee(EmployeeListDTO updateempDto);
        Task<ServiceResponse<string>> DeleteEmployee(int id);
    }
}
